package context

import (
	"nwdaf.com/factory"
)

func SetupNWDAFContext(config *factory.Config) error {
	return nil
}
