package util

var (
	NwdafLogPath = "nwdaf.com/util"
)
